class Snake {
    constructor(x, y, w, h, c) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.c = c;
    }
    drawSnake(xPos, yPos) {
        positions.push({
            x: xPos,
            y: yPos
        });
        if (positions.length > snakeLength) {
            positions.shift();
        }
        for (var i = 0; i < positions.length; i++) {
            colorRect(positions[i].x, positions[i].y, OBJ_SIZE, OBJ_SIZE, '#00CC66');
            colorRect(xPos, yPos, OBJ_SIZE, OBJ_SIZE, '#00FF80');
        }
    }
    touchCases() {
        for (var i = 0; i < positions.length - 1; i++) {
            if (xPos == positions[i].x && yPos == positions[i].y) {
                gameOver()
            }
        }

        if (xPos == food.x && yPos == food.y) {
            food.foodMove();
        }
        if (xPos < 0) {
            gameOver();
        }
        if (xPos >= canvas.width) {
            gameOver();
        }
        if (yPos < 0) {
            gameOver();
        }
        if (yPos >= canvas.height) {
            gameOver();
        }
    }
    movement() {
        if (isGameOver) return;
        if (upKeyPressed) {
            yPos -= OBJ_SIZE
        }
        if (downKeyPressed) {
            yPos += OBJ_SIZE
        }
        if (leftKeyPressed) {
            xPos -= OBJ_SIZE
        }
        if (rightKeyPressed) {
            xPos += OBJ_SIZE
        }
    }
    stopMove() {
        upKeyPressed = false;
        downKeyPressed = false;
        leftKeyPressed = false;
        rightKeyPressed = false;
    }
}
