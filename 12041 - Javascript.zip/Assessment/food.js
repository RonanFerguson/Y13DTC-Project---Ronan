class Item {
        constructor(x, y, w, h, c) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.c = c;
        }
        drawItem() {
            canvasContext.fillStyle = this.c;
            canvasContext.fillRect(this.x, this.y, this.w, this.h);
        }

        foodMove() {
            snakeLength += foodIncrease;
            score += 1;
            this.x = Math.floor(Math.random() * (800 / OBJ_SIZE)) * OBJ_SIZE;
            this.y = Math.floor(Math.random() * (800 / OBJ_SIZE)) * OBJ_SIZE;
        }
    }
